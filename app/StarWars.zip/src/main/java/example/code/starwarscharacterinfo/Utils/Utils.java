package example.code.starwarscharacterinfo.Utils;

public class Utils {

    public static final String NAME = "name";
    public static final String HEIGHT = "height";
    public static final String WEIGHT = "weight";
    public static final String DATE = "date";

}
